<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <div class="card text-left">
              <div class="card-header">
                  <h4>Add New Task</h4>
              </div>
              <div class="card-body">
                <form action="/task" method="post">
                    <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="task">Task</label>
                    <input type="text" name="taskname" id="taskname" class="form-control">
                  </div>
                  <div class="form-group">
                    <button type="submit" class="btn btn-primary">Add Task</button>
                  </div>
                </form>
              </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card text-left">
                <div class="card-header">
                    <h4>Current Tasks</h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped task-table">
                        <thead>
                            <th>Task</th>
                            <th>&nbsp;</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="table-text">
                                        <div><?php echo e($task->name); ?></div>
                                    </td>
    
                                    <td>
                                        <form action="/task/<?php echo e($task->id); ?>" method="post">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger">Delete Task</button>
                                        </form>
                                    </td>
                                </tr>
                                 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div>
                        <?php echo e($tasks->links()); ?>

                    </div>
                    
                </div>
              </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CipherFusion\Documents\ejrp\todolist\resources\views/tasks/index.blade.php ENDPATH**/ ?>