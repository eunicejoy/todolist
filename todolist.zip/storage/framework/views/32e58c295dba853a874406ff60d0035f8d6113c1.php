;
<?php $__env->startSection('content'); ?>;
<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <div class="card text-left">
                <div class="card-header">
                    <h4>Add New Item</h4>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('messages.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                    <form action="/grocery" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" name="name" id="name" placeholder="Name">
                        <input type="text" name="qty" id="qty" placeholder="Quantity">
                    </div>
                    <div class="form-group">
                        <input type="submit" value="
                        Add">
                    </div>
                    </form>
                </div>
            </div>
            <hr>
            <div class="card text-left">
                <div class="card-header">
                    <h4>Bought Items</h4>
                </div>
                <div class="card-body">

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Eunice\Documents\Laravel-outputs\todolist\resources\views/grocery/index.blade.php ENDPATH**/ ?>