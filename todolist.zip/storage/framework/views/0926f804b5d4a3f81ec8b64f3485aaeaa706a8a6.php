<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <div class="card text-left">
              <div class="card-header">
                  <h4>Add New Task</h4>
              </div>
              <div class="card-body">
                  <?php echo $__env->make('messages.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="/task" method="post">
                    <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <input type="text" name="taskname" id="taskname" class="form-control">
                  </div>
                  <div class="form-group">
                    <button type="submit" class="btn btn-primary">Add</button>
                  </div>
                </form>
              </div>
            </div>
            <hr>
            <div class="card text-left">
                <div class="card-header">
                    <h4>Finished Tasks</h4>
                </div>
                <div class="card-body">
                    <?php if($tasks_done->count() > 0): ?>
                            <?php $__currentLoopData = $tasks_done; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_done): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-sm-10">
                                    <h5><?php echo e($task_done->name); ?></h5>
                                    <span class="offset-sm-5"><small>finished at: <i><?php echo e($task_done->finished_at); ?></i></small></span>
                                </div>
                                <div class="col-sm-2">
                                    <form action="/task/<?php echo e($task_done->id); ?>" method="post">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                            <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                           <!-- <div>
                             
                            </div> !-->
                    <?php else: ?>
                    <p>No task yet.</p>
                    <?php endif; ?>
                    <details>
                        <summary>Click Here</summary>
                        Stay home and keep safe!
                    </details>
                </div>
              </div>
        </div>
        <div class="col-sm-6">
            <div class="card text-left">
                <div class="card-header">
                    <h4>Current Tasks</h4>
                </div>
                <div class="card-body">
                    <?php if($tasks->count() > 0): ?>
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">

                                <div class="col-sm-8">
                                    <h5><?php echo e($task->name); ?></h5>
                                    <span class="offset-sm-5"><small>created at: <i><?php echo e($task->created_at); ?></i></small></span>
                                </div>

                                <div class="col-sm-2">
                                    <button type="button"
                                    class="btn btn-success"
                                    data-target="#editModal"
                                    data-toggle="modal"
                                    data-taskid= <?php echo e($task->id); ?>

                                    data-name="<?php echo e($task->name); ?>">Edit</button>
                                </div>

                                <div class="col-sm-2">
                                    <form action="/finished/<?php echo e($task->id); ?>" method="post">
                                    <?php echo method_field('PATCH'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-warning">Done</button>
                                    </form>
                                </div>
                            </div>
                            <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div>
                                <?php echo e($tasks->links()); ?>

                            </div>

                    <?php else: ?>
                    <p>No task yet.</p>
                    <?php endif; ?>

                </div>
              </div>
        </div>
    </div>
</div>



<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit Task
          </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form action="/update" method="post">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" hidden id="taskid" name="taskid">
              <input type="text" class="form-control" id="task" name="task">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script type="application/javascript">
    $(document).ready(function(){
        $("#edit").click(function(){
            $("#editModal").modal();
        });

        $('#editModal').on('show.bs.modal', function(event){
            var button = $(event.relatedTarget);
            var name = button.data('name');
            var id = button.data('taskid');
            var modal = $(this);

            modal.find('#task').val(name);
            modal.find('#taskid').val(id);
        });
    });

  </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Eunice\Documents\Laravel-outputs\todolist\resources\views/tasks/index.blade.php ENDPATH**/ ?>