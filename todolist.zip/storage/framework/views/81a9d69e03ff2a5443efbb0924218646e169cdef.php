<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <strong>Something went wrong!</strong>
        <br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
    </div>
<?php else: ?>

<?php endif; ?>
<?php /**PATH C:\Users\Eunice\Documents\Laravel-outputs\todolist\resources\views/messages/errors.blade.php ENDPATH**/ ?>